package com.example.Util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.model.ToDoModel;
import java.util.ArrayList;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "todoListDatabase";
    private static final String TABLE_NAME = "ToDoTasks";
    private static final String ID = "id";
    private static final String TASK = "task";
    private static final String STATUS = "status";
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + TASK + " TEXT," + STATUS + " INTEGER NOT NULL DEFAULT 0)";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDB){
         sqLiteDB.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDB, int oldVersion, int newVersion){
        sqLiteDB.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(sqLiteDB);
    }

    public void insertTask(String task){
        try(SQLiteDatabase sqlDB=this.getWritableDatabase()){
            ContentValues values=new ContentValues();
            values.put(TASK,task);
            values.put(STATUS,0);
            sqlDB.insert(TABLE_NAME,null,values);
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteTask(int id){
        try(SQLiteDatabase sqlDB=this.getReadableDatabase()){
            sqlDB.delete(TABLE_NAME,ID+" = ?",new String[]{String.valueOf(id)});
        }catch(Exception e) {
            System.out.println("Exception in 'deleteTask' method.");
            System.out.println(e.getMessage());
        }
    }

    public void updateStatus(int id,int status){
        try(SQLiteDatabase sqlDB=this.getWritableDatabase()){
            ContentValues values=new ContentValues();
            values.put(STATUS,status);
            System.out.println(values);
            sqlDB.update(TABLE_NAME,values,ID+" = ?",new String[]{String.valueOf(id)});
        }catch (Exception e){
            System.out.println("Exception in 'updateStatus' method.");
            System.out.println(e.getMessage());
        }
    }

    public int getRecentTaskID(){
        int id=0;
        try(SQLiteDatabase sqlDB=this.getReadableDatabase();
            Cursor cursor=sqlDB.rawQuery("SELECT * FROM "+TABLE_NAME+" ORDER BY "+ID+" DESC LIMIT 1",null)){
                if(cursor.moveToFirst()){
                    id= cursor.getInt(cursor.getColumnIndexOrThrow(ID));
                }
        }catch (Exception e){
            System.out.println("Exception in 'getRecentTask' method.");
            System.out.println(e.getMessage());
        }
        return id;
    }


    public ArrayList<ToDoModel> getAllTasks(){
        ArrayList<ToDoModel> taskList=new ArrayList<>();

        try(SQLiteDatabase sqlDB=this.getReadableDatabase();
            Cursor cursor=sqlDB.rawQuery("SELECT * FROM "+TABLE_NAME,null)){
            if(cursor.moveToFirst()) {
                do{
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(ID));
                    String taskText = cursor.getString(cursor.getColumnIndexOrThrow(TASK));
                    int status = cursor.getInt(cursor.getColumnIndexOrThrow(STATUS));
                    ToDoModel task = new ToDoModel(id, status, taskText);
                    taskList.add(task);
                }while(cursor.moveToNext());
            }
        }catch(Exception e) {
            System.out.println("Exception in 'getAllTasks' method.");
            System.out.println(e.getMessage());
        }
        return taskList;
    }
}
