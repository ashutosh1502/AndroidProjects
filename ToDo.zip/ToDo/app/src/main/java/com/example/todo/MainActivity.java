package com.example.todo;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.Util.DatabaseHandler;
import com.example.model.ToDoModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private LinearLayout taskContainer;
    private EditText addTodoText;
    private AppCompatButton addTodoBtn;
    private DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        taskContainer = findViewById(R.id.task_container);
        addTodoText = findViewById(R.id.add_todo);
        addTodoBtn = findViewById(R.id.add_todo_btn);

        dbHandler=new DatabaseHandler(this);

        ArrayList<ToDoModel> taskList=dbHandler.getAllTasks();
        for(int i=0;i<taskList.size();i++){
            addTask(taskList.get(i).getId(),taskList.get(i).getTask(),taskList.get(i).getStatus());
        }

        addTodoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskText=addTodoText.getText().toString().trim();

                if(!taskText.isEmpty()){
                    dbHandler.insertTask(taskText);
                    addTask(dbHandler.getRecentTaskID(),taskText,0);
                    addTodoText.setText("");
                }else{
                    Toast.makeText(MainActivity.this,"Please enter a task", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void addTask(int id,String taskText,int status) {
        View taskView=getLayoutInflater().inflate(R.layout.new_task,taskContainer,false);

        TextView taskTextview=taskView.findViewById(R.id.task_text);
        taskTextview.setText(taskText);

        AppCompatButton deleteBtn=taskView.findViewById(R.id.delete_task);
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler.deleteTask(id);
                taskContainer.removeView(taskView);
            }
        });

        CheckBox taskDone=taskView.findViewById(R.id.task_done);
        taskDone.setActivated(false);
        taskDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler.updateStatus(id,(taskDone.isChecked())?1:0);
                taskTextview.setPaintFlags(taskTextview.getPaintFlags()^android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            }
        });

        if(status==1){
            taskDone.setChecked(true);
            taskTextview.setPaintFlags(taskTextview.getPaintFlags()^android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        }

        taskContainer.addView(taskView);
    }
}